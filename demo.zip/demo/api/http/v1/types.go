package v1

type LoginReq struct {
	Account string `json:"account"`
	Passwd  string `json:"passwd"`
}

type LoginData struct {
	UserToken string `json:"userToken"`
	AppID     string `json:"appId"`
}

type LoginRes struct {
	Code int        `json:"code"`
	Msg  string     `json:"msg,omitempty"`
	Data *LoginData `json:"data,omitempty"`
}

type GetSDKTokenReq struct {
	Token  string `json:"token"`
	RoomID string `json:"roomId"`
}

type GetSDKTokenData struct {
	SDKToken string `json:"sdkToken"`
	AppID    string `json:"appId"`
	RoomName string `json:"roomName"`
}

type GetSDKTokenRes struct {
	Code int              `json:"code"`
	Msg  string           `json:"msg,omitempty"`
	Data *GetSDKTokenData `json:"data,omitempty"`
}

type UpdateVersionReq struct {
	IsForceUpdate bool   `json:"isForceUpdate"`
	NewVersion    string `json:"newVersion"`
	Desc          string `json:"desc"`
	URL           string `json:"url"`
}

type CommonRes struct {
	Code int    `json:"code"`
	Msg  string `json:"msg,omitempty"`
}
