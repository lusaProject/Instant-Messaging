package db

import (
	"github.com/go-redis/redis"
)

func RedisInit(addr string, password string) (cli *redis.Client, err error) {
	client := redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password,
	})

	_, err = client.Ping().Result()
	if err != nil {
		return nil, err
	}
	return client, nil
}
