package dao

import (
	"demo/internal/model/entity"
	"strconv"
	"strings"

	"github.com/go-redis/redis"
)

const versionKey = "version"

func SaveVersion(client *redis.Client, v entity.Version) error {
	pipe := client.TxPipeline()
	pipe.HSet(versionKey, "isForceUpdate", boolToInt(v.IsForceUpdate))
	pipe.HSet(versionKey, "newVersion", v.NewVersion)
	pipe.HSet(versionKey, "desc", v.Desc)
	pipe.HSet(versionKey, "url", v.URL)
	_, err := pipe.Exec()
	return err
}

func GetVersion(client *redis.Client) (entity.Version, error) {
	values, err := client.HMGet(versionKey, "isForceUpdate", "newVersion", "desc", "url").Result()
	if err != nil {
		return entity.Version{}, err
	}

	var v entity.Version
	if len(values) > 0 {
		v.IsForceUpdate = parseForceUpdate(values[0])
	}
	if len(values) > 1 {
		v.NewVersion = toString(values[1])
	}
	if len(values) > 2 {
		v.Desc = toString(values[2])
	}
	if len(values) > 3 {
		v.URL = toString(values[3])
	}
	return v, nil
}

func boolToInt(flag bool) int {
	if flag {
		return 1
	}
	return 0
}

func parseForceUpdate(raw interface{}) bool {
	switch v := raw.(type) {
	case nil:
		return false
	case bool:
		return v
	case int:
		return v == 1
	case int64:
		return v == 1
	case float64:
		return v == 1
	case []byte:
		return parseForceUpdate(strings.TrimSpace(string(v)))
	case string:
		s := strings.TrimSpace(strings.ToLower(v))
		if s == "" {
			return false
		}
		if s == "1" {
			return true
		}
		if s == "0" {
			return false
		}
		b, err := strconv.ParseBool(s)
		if err == nil {
			return b
		}
		n, err := strconv.ParseInt(s, 10, 64)
		return err == nil && n == 1
	default:
		return false
	}
}

func toString(raw interface{}) string {
	switch v := raw.(type) {
	case nil:
		return ""
	case string:
		return v
	case []byte:
		return string(v)
	default:
		return ""
	}
}
