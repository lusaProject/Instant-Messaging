package service

import "testing"

func TestCompareVersions(t *testing.T) {
	tests := []struct {
		name string
		v1   string
		v2   string
		want int
	}{
		{name: "equal", v1: "1.2.3", v2: "1.2.3", want: 0},
		{name: "lower patch", v1: "1.2.2", v2: "1.2.3", want: -1},
		{name: "higher major", v1: "2.0.0", v2: "1.9.9", want: 1},
		{name: "shorter lower", v1: "1.2", v2: "1.2.0", want: -1},
		{name: "longer higher", v1: "1.2.0", v2: "1.2", want: 1},
		{name: "non numeric fallback", v1: "1.a.0", v2: "1.1.0", want: -1},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := compareVersions(tt.v1, tt.v2)
			if got != tt.want {
				t.Fatalf("compareVersions(%q, %q) = %d, want %d", tt.v1, tt.v2, got, tt.want)
			}
		})
	}
}
