package service

import (
	"context"
	"demo/internal/controller"
	db "demo/internal/dao/db"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

func ServiceInit() error {
	appCfg = loadServiceConfig()
	CloudFlare = appCfg.cloudFlareURL
	AppId = appCfg.appID
	AppKey = appCfg.appKey

	var err error
	clientDB, err = db.RedisInit(appCfg.redisAddr, appCfg.redisPassword)
	if err != nil {
		return err
	}
	defer func() {
		if clientDB == nil {
			return
		}
		if err := clientDB.Close(); err != nil {
			log.Printf("redis close failed: %v", err)
		}
	}()

	asyncCronScheduler()

	upgrader.CheckOrigin = func(r *http.Request) bool {
		origin := strings.TrimSpace(r.Header.Get("Origin"))
		if origin == "" {
			return true
		}
		return appCfg.isOriginAllowed(origin)
	}

	mux := http.NewServeMux()
	controller.RegisterRoutes(mux, controller.HTTPHandlers{
		WebSocket:     handleConnections,
		Upload:        uploadHandler,
		Login:         loginHandler,
		GetSDKToken:   getSdkTokenHandler,
		UpdateVersion: updateVersionHandler,
	})

	server := &http.Server{
		Addr:              appCfg.serverAddr,
		Handler:           mux,
		ReadHeaderTimeout: appCfg.readHeaderTimeout,
		ReadTimeout:       appCfg.readTimeout,
		WriteTimeout:      appCfg.writeTimeout,
		IdleTimeout:       appCfg.idleTimeout,
	}

	serverErrCh := make(chan error, 1)
	go func() {
		if appCfg.tlsCertFile != "" && appCfg.tlsKeyFile != "" {
			log.Printf("server started with TLS on %s", appCfg.serverAddr)
			serverErrCh <- server.ListenAndServeTLS(appCfg.tlsCertFile, appCfg.tlsKeyFile)
			return
		}
		log.Printf("server started without TLS on %s", appCfg.serverAddr)
		serverErrCh <- server.ListenAndServe()
	}()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	select {
	case err := <-serverErrCh:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			return err
		}
		return nil
	case <-ctx.Done():
		log.Printf("shutdown signal received")
	}

	shutdownCtx, cancel := context.WithTimeout(context.Background(), appCfg.shutdownTimeout)
	defer cancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		return err
	}

	select {
	case err := <-serverErrCh:
		if err != nil && !errors.Is(err, http.ErrServerClosed) {
			return err
		}
	case <-time.After(2 * time.Second):
	}

	return nil
}
