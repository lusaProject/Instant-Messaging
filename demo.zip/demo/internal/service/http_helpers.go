package service

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net/http"
)

func requireMethod(w http.ResponseWriter, r *http.Request, method string) bool {
	if r.Method == method {
		return true
	}
	w.Header().Set("Allow", method)
	writeJSONResponse(w, http.StatusMethodNotAllowed, map[string]interface{}{
		"code": http.StatusMethodNotAllowed,
		"msg":  "method not allowed",
	})
	return false
}

func decodeJSONBody(r *http.Request, dst interface{}, maxBytes int64) error {
	defer r.Body.Close()

	var reader io.Reader = r.Body
	if maxBytes > 0 {
		reader = io.LimitReader(r.Body, maxBytes+1)
	}
	payload, err := io.ReadAll(reader)
	if err != nil {
		return err
	}
	if maxBytes > 0 && int64(len(payload)) > maxBytes {
		return errors.New("request body too large")
	}

	decoder := json.NewDecoder(bytes.NewReader(payload))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(dst); err != nil {
		return err
	}
	if err := decoder.Decode(&struct{}{}); err != io.EOF {
		if err == nil {
			return errors.New("request body must contain a single JSON object")
		}
		return err
	}
	return nil
}

func writeJSONResponse(w http.ResponseWriter, statusCode int, payload interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	if err := json.NewEncoder(w).Encode(payload); err != nil {
		http.Error(w, "failed to encode response", http.StatusInternalServerError)
	}
}
