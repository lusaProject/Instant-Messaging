package service

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/dgrijalva/jwt-go"
	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

func handleConnections(w http.ResponseWriter, r *http.Request) {
	userToken := r.Header.Get("User-Token")
	userRecv := r.Header.Get("User")

	var temp bool
	if userToken == "" {
		userToken = r.URL.Query().Get("user_token")
		userRecv = r.URL.Query().Get("user")
		temp = true
	} else {
		temp = false
	}

	var userid string
	{
		tokenString := userToken
		token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
			if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
				return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
			}
			return []byte(appCfg.jwtSigningKey), nil
		})
		if err != nil {
			writeAuthError(w, http.StatusUnauthorized, 1005, "Failed to decode or validate token")
			return
		}

		if !token.Valid {
			writeAuthError(w, http.StatusUnauthorized, 1006, "Invalid token")
			return
		}

		claims, ok := token.Claims.(jwt.MapClaims)
		if !ok {
			writeAuthError(w, http.StatusUnauthorized, 1007, "Invalid token claims")
			return
		}

		account := fmt.Sprintf("%v", claims["account"])
		if account == "" || account == "<nil>" {
			writeAuthError(w, http.StatusUnauthorized, 1008, "Missing account in token")
			return
		}
		userid = account
	}

	ws, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("websocket upgrade failed: %v", err)
		return
	}
	defer ws.Close()
	ws.SetReadLimit(1 << 20)

	mu_ws.Lock()
	clients[userid] = ws
	mu_ws.Unlock()
	saveUserInfo(userRecv, userid, temp)

	for {
		var data map[string]interface{}

		err := ws.ReadJSON(&data)
		if err != nil {
			user := getUserBase(userid)
			log.Printf("close: %v-%s", err, user.Name)
			go closeConnect(temp, userid)
			break
		}

		event, _ := data["event"].(string)
		if event != "ping" && event != "queryAllUsers" {
			user := getUserBase(userid)
			log.Print(data, "-", user.Name)
		}

		mu_ws.Lock()
		_, ok := clients[userid]
		if !ok {
			clients[userid] = ws

			var user UserInfo
			user.Timestamp = "0"
			userInfoHSet(userid, user)
		}
		mu_ws.Unlock()

		go signaling(userid, data)
		go liveRoomEvent(userid, data)
	}
}

func writeAuthError(w http.ResponseWriter, statusCode int, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	_ = json.NewEncoder(w).Encode(map[string]interface{}{
		"code": code,
		"msg":  msg,
	})
}
