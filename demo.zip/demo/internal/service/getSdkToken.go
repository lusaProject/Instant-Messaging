package service

import (
	apiv1 "demo/api/http/v1"
	"fmt"
	"net/http"
	"strings"

	"github.com/dgrijalva/jwt-go"
	"github.com/google/uuid"
)

func getSdkTokenHandler(w http.ResponseWriter, r *http.Request) {
	if !requireMethod(w, r, http.MethodPost) {
		return
	}

	var req apiv1.GetSDKTokenReq
	if err := decodeJSONBody(r, &req, 1<<20); err != nil {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid request body",
		})
		return
	}

	req.Token = strings.TrimSpace(req.Token)
	req.RoomID = strings.TrimSpace(req.RoomID)
	if req.Token == "" {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: 1001,
			Msg:  "invalid input",
		})
		return
	}

	token, err := jwt.Parse(req.Token, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(appCfg.jwtSigningKey), nil
	})
	if err != nil {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: 1005,
			Msg:  "Failed to decode or validate token",
		})
		return
	}

	if !token.Valid {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: 1006,
			Msg:  "Invalid token",
		})
		return
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: 1007,
			Msg:  "Invalid token claims",
		})
		return
	}

	userid := strings.TrimSpace(fmt.Sprintf("%v", claims["account"]))
	if userid == "" || userid == "<nil>" {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: 1008,
			Msg:  "Missing account in token",
		})
		return
	}

	roomID := req.RoomID
	if roomID == "" {
		roomID = uuid.New().String()
	}

	sdkToken := getSdkToken(AppId, AppKey, roomID, userid)
	writeJSONResponse(w, http.StatusOK, apiv1.GetSDKTokenRes{
		Code: 200,
		Data: &apiv1.GetSDKTokenData{
			SDKToken: sdkToken,
			AppID:    AppId,
			RoomName: roomID,
		},
	})
}
