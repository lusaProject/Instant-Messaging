package service

import (
	apiv1 "demo/api/http/v1"
	"log"
	"net/http"
	"strings"

	"github.com/dgrijalva/jwt-go"
)

func loginHandler(w http.ResponseWriter, r *http.Request) {
	if !requireMethod(w, r, http.MethodPost) {
		return
	}

	authHeader := strings.TrimSpace(r.Header.Get("Authorization"))
	if authHeader != appCfg.loginBearerToken {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: http.StatusUnauthorized,
			Msg:  "unauthorized",
		})
		return
	}

	var req apiv1.LoginReq
	if err := decodeJSONBody(r, &req, 1<<20); err != nil {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid request body",
		})
		return
	}

	req.Account = strings.TrimSpace(req.Account)
	req.Passwd = strings.TrimSpace(req.Passwd)
	if req.Account == "" || req.Passwd == "" {
		writeJSONResponse(w, http.StatusUnauthorized, apiv1.CommonRes{
			Code: http.StatusUnauthorized,
			Msg:  "invalid account or password",
		})
		return
	}

	token := jwt.New(jwt.SigningMethodHS256)
	claims := token.Claims.(jwt.MapClaims)
	claims["account"] = req.Account
	claims["expiresDate"] = "2726643496"
	tokenString, err := token.SignedString([]byte(appCfg.jwtSigningKey))
	if err != nil {
		log.Printf("failed to generate token: %v", err)
		writeJSONResponse(w, http.StatusInternalServerError, apiv1.CommonRes{
			Code: http.StatusInternalServerError,
			Msg:  "failed to generate token",
		})
		return
	}

	writeJSONResponse(w, http.StatusOK, apiv1.LoginRes{
		Code: 200,
		Data: &apiv1.LoginData{
			UserToken: tokenString,
			AppID:     AppId,
		},
	})
}
