package service

import (
	"demo/internal/dao"
	modeldo "demo/internal/model/do"
	"demo/internal/model/entity"
	"strings"
)

func saveVersionByModel(input modeldo.UpdateVersionInput) (modeldo.UpdateVersionOutput, error) {
	versionEntity := entity.Version{
		IsForceUpdate: input.IsForceUpdate,
		NewVersion:    strings.TrimSpace(input.NewVersion),
		Desc:          strings.TrimSpace(input.Desc),
		URL:           strings.TrimSpace(input.URL),
	}
	if err := dao.SaveVersion(clientDB, versionEntity); err != nil {
		return modeldo.UpdateVersionOutput{}, err
	}

	return modeldo.UpdateVersionOutput{
		IsForceUpdate: versionEntity.IsForceUpdate,
		NewVersion:    versionEntity.NewVersion,
		Desc:          versionEntity.Desc,
		URL:           versionEntity.URL,
	}, nil
}

func checkVersionByModel(input modeldo.CheckVersionInput) (modeldo.CheckVersionOutput, error) {
	versionEntity, err := dao.GetVersion(clientDB)
	if err != nil {
		return modeldo.CheckVersionOutput{}, err
	}

	currentVersion := strings.TrimSpace(input.CurrentVersion)
	hasNewVersion := false
	if currentVersion != "" && versionEntity.NewVersion != "" {
		hasNewVersion = compareVersions(currentVersion, versionEntity.NewVersion) == -1
	}

	return modeldo.CheckVersionOutput{
		HasNewVersion: hasNewVersion,
		IsForceUpdate: versionEntity.IsForceUpdate,
		NewVersion:    versionEntity.NewVersion,
		Desc:          versionEntity.Desc,
		URL:           versionEntity.URL,
	}, nil
}
