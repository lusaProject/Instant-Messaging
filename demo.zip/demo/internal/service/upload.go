package service

import (
	apiv1 "demo/api/http/v1"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

var uploadTypePattern = regexp.MustCompile(`^[a-zA-Z0-9_-]+$`)

func uploadHandler(w http.ResponseWriter, r *http.Request) {
	if !requireMethod(w, r, http.MethodPost) {
		return
	}

	r.Body = http.MaxBytesReader(w, r.Body, appCfg.maxUploadBytes+1024)
	if err := r.ParseMultipartForm(appCfg.maxUploadBytes); err != nil {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid multipart form or file too large",
		})
		return
	}

	fileType := strings.TrimSpace(r.FormValue("type"))
	if fileType == "" || !uploadTypePattern.MatchString(fileType) {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid upload type",
		})
		return
	}
	if !appCfg.isUploadTypeAllowed(fileType) {
		writeJSONResponse(w, http.StatusForbidden, apiv1.CommonRes{
			Code: http.StatusForbidden,
			Msg:  "upload type is not allowed",
		})
		return
	}

	file, fileHeader, err := r.FormFile("file")
	if err != nil {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "missing file",
		})
		return
	}
	defer file.Close()

	resultDir := filepath.Join(appCfg.uploadBaseDir, fileType)
	if err := os.MkdirAll(resultDir, 0o755); err != nil {
		log.Printf("create upload dir failed: %v", err)
		writeJSONResponse(w, http.StatusInternalServerError, apiv1.CommonRes{
			Code: http.StatusInternalServerError,
			Msg:  "failed to create upload directory",
		})
		return
	}

	fileName := filepath.Base(strings.TrimSpace(fileHeader.Filename))
	if fileName == "" || fileName == "." {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid file name",
		})
		return
	}

	targetPath := filepath.Join(resultDir, fileName)
	if err := saveFile(file, targetPath); err != nil {
		log.Printf("save upload file failed: %v", err)
		writeJSONResponse(w, http.StatusInternalServerError, apiv1.CommonRes{
			Code: http.StatusInternalServerError,
			Msg:  "failed to save file",
		})
		return
	}

	writeJSONResponse(w, http.StatusOK, apiv1.CommonRes{
		Code: 0,
		Msg:  "success",
	})
}

func saveFile(file multipart.File, path string) error {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()

	_, err = io.Copy(f, file)
	return err
}
