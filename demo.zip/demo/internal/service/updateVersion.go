package service

import (
	apiv1 "demo/api/http/v1"
	"log"
	"net/http"
	"strings"

	modeldo "demo/internal/model/do"
)

func updateVersionHandler(w http.ResponseWriter, r *http.Request) {
	if !requireMethod(w, r, http.MethodPost) {
		return
	}

	var req apiv1.UpdateVersionReq
	if err := decodeJSONBody(r, &req, 1<<20); err != nil {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "invalid request body",
		})
		return
	}

	req.NewVersion = strings.TrimSpace(req.NewVersion)
	req.Desc = strings.TrimSpace(req.Desc)
	req.URL = strings.TrimSpace(req.URL)
	if req.NewVersion == "" {
		writeJSONResponse(w, http.StatusBadRequest, apiv1.CommonRes{
			Code: http.StatusBadRequest,
			Msg:  "newVersion is required",
		})
		return
	}

	output, err := saveVersionByModel(modeldo.UpdateVersionInput{
		IsForceUpdate: req.IsForceUpdate,
		NewVersion:    req.NewVersion,
		Desc:          req.Desc,
		URL:           req.URL,
	})
	if err != nil {
		log.Printf("update version failed: %v", err)
		writeJSONResponse(w, http.StatusInternalServerError, apiv1.CommonRes{
			Code: http.StatusInternalServerError,
			Msg:  "failed to update version",
		})
		return
	}
	if output.NewVersion == "" {
		writeJSONResponse(w, http.StatusInternalServerError, apiv1.CommonRes{
			Code: http.StatusInternalServerError,
			Msg:  "failed to update version",
		})
		return
	}

	writeJSONResponse(w, http.StatusOK, apiv1.CommonRes{
		Code: 0,
		Msg:  "success",
	})
}
