package service

import (
	"os"
	"strconv"
	"strings"
	"time"
)

type serviceConfig struct {
	serverAddr          string
	tlsCertFile         string
	tlsKeyFile          string
	shutdownTimeout     time.Duration
	readHeaderTimeout   time.Duration
	readTimeout         time.Duration
	writeTimeout        time.Duration
	idleTimeout         time.Duration
	redisAddr           string
	redisPassword       string
	jwtSigningKey       string
	loginBearerToken    string
	cloudFlareURL       string
	appID               string
	appKey              string
	uploadBaseDir       string
	maxUploadBytes      int64
	allowedUploadTypes  map[string]struct{}
	wsAllowedOrigins    map[string]struct{}
	outboundHTTPTimeout time.Duration
}

var appCfg = loadServiceConfig()

func loadServiceConfig() serviceConfig {
	return serviceConfig{
		serverAddr:          getEnv("SERVER_ADDR", ":8099"),
		tlsCertFile:         strings.TrimSpace(os.Getenv("TLS_CERT_FILE")),
		tlsKeyFile:          strings.TrimSpace(os.Getenv("TLS_KEY_FILE")),
		shutdownTimeout:     getEnvDuration("SHUTDOWN_TIMEOUT", 10*time.Second),
		readHeaderTimeout:   getEnvDuration("HTTP_READ_HEADER_TIMEOUT", 5*time.Second),
		readTimeout:         getEnvDuration("HTTP_READ_TIMEOUT", 15*time.Second),
		writeTimeout:        getEnvDuration("HTTP_WRITE_TIMEOUT", 15*time.Second),
		idleTimeout:         getEnvDuration("HTTP_IDLE_TIMEOUT", 30*time.Second),
		redisAddr:           getEnv("REDIS_ADDR", "127.0.0.1:6379"),
		redisPassword:       strings.TrimSpace(os.Getenv("REDIS_PASSWORD")),
		jwtSigningKey:       getEnv("JWT_SIGNING_KEY", "XLC8J22HOmTT2zZyeRVq3RKQ3juNkZR6OJUgIW2Y"),
		loginBearerToken:    getEnv("LOGIN_BEARER_TOKEN", "Bearer cf_qzIFKgPbmvAlfuGdlkpOKvSBnVlrirHeAq"),
		cloudFlareURL:       getEnv("CLOUDFLARE_BASE_URL", "https://demo.putplay.cc"),
		appID:               getEnv("APP_ID", "A6B499768801E248ACA11E5F842DB6DF"),
		appKey:              getEnv("APP_KEY", "6E38A16897E37A932896B4044882391F794C0358B1E94E7A2F09C132A96D9385"),
		uploadBaseDir:       getEnv("UPLOAD_BASE_DIR", "/var/data"),
		maxUploadBytes:      getEnvInt64("MAX_UPLOAD_BYTES", 20<<20),
		allowedUploadTypes:  buildLookupSet(os.Getenv("UPLOAD_ALLOWED_TYPES")),
		wsAllowedOrigins:    buildLookupSet(os.Getenv("WS_ALLOWED_ORIGINS")),
		outboundHTTPTimeout: getEnvDuration("OUTBOUND_HTTP_TIMEOUT", 10*time.Second),
	}
}

func (c serviceConfig) isUploadTypeAllowed(kind string) bool {
	if len(c.allowedUploadTypes) == 0 {
		return true
	}
	_, ok := c.allowedUploadTypes[kind]
	return ok
}

func (c serviceConfig) isOriginAllowed(origin string) bool {
	if len(c.wsAllowedOrigins) == 0 {
		return true
	}
	_, ok := c.wsAllowedOrigins[origin]
	return ok
}

func buildLookupSet(raw string) map[string]struct{} {
	set := make(map[string]struct{})
	for _, item := range strings.Split(raw, ",") {
		item = strings.TrimSpace(item)
		if item == "" {
			continue
		}
		set[item] = struct{}{}
	}
	return set
}

func getEnv(key string, fallback string) string {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return fallback
	}
	return v
}

func getEnvInt64(key string, fallback int64) int64 {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return fallback
	}
	num, err := strconv.ParseInt(v, 10, 64)
	if err != nil || num <= 0 {
		return fallback
	}
	return num
}

func getEnvDuration(key string, fallback time.Duration) time.Duration {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return fallback
	}
	d, err := time.ParseDuration(v)
	if err != nil || d <= 0 {
		return fallback
	}
	return d
}
