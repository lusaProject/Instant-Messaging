package entity

type Version struct {
	IsForceUpdate bool
	NewVersion    string
	Desc          string
	URL           string
}
