package do

type UpdateVersionInput struct {
	IsForceUpdate bool
	NewVersion    string
	Desc          string
	URL           string
}

type UpdateVersionOutput struct {
	IsForceUpdate bool
	NewVersion    string
	Desc          string
	URL           string
}

type CheckVersionInput struct {
	CurrentVersion string
}

type CheckVersionOutput struct {
	HasNewVersion bool
	IsForceUpdate bool
	NewVersion    string
	Desc          string
	URL           string
}
