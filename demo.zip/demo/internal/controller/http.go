package controller

import "net/http"

type HTTPHandlers struct {
	WebSocket     http.HandlerFunc
	Upload        http.HandlerFunc
	Login         http.HandlerFunc
	GetSDKToken   http.HandlerFunc
	UpdateVersion http.HandlerFunc
}

func RegisterRoutes(mux *http.ServeMux, h HTTPHandlers) {
	if h.WebSocket != nil {
		mux.HandleFunc("/ws", h.WebSocket)
	}
	if h.Upload != nil {
		mux.HandleFunc("/upload", h.Upload)
	}
	if h.Login != nil {
		mux.HandleFunc("/login", h.Login)
	}
	if h.GetSDKToken != nil {
		mux.HandleFunc("/getSdkToken", h.GetSDKToken)
	}
	if h.UpdateVersion != nil {
		mux.HandleFunc("/updateVersion", h.UpdateVersion)
	}
}
