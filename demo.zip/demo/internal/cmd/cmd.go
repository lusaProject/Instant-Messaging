package cmd

import (
	"demo/internal/service"
)

func Init() error {
	return service.ServiceInit()
}
