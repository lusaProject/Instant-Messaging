package main

import (
	"demo/internal/cmd"
	"log"
)

func main() {
	if err := cmd.Init(); err != nil {
		log.Fatalf("service startup failed: %v", err)
	}
}
