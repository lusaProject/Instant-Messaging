﻿# demo

一个基于 Go + Redis + WebSocket 的实时互动服务。

## 快速启动

1. 启动 Redis（默认 `127.0.0.1:6379`）。
2. 设置必要环境变量（见下方配置表）。
3. 运行：

```bash
go run .
```

或使用 Makefile：

```bash
make build
make test
```

Docker 构建：

```bash
docker build -f manifest/docker/Dockerfile -t demo:latest .
docker run --rm -p 8099:8099 demo:latest
```

## 关键环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `SERVER_ADDR` | `:8099` | HTTP/WS 监听地址 |
| `TLS_CERT_FILE` | 空 | TLS 证书路径（与 `TLS_KEY_FILE` 同时配置才启用 TLS） |
| `TLS_KEY_FILE` | 空 | TLS 私钥路径 |
| `REDIS_ADDR` | `127.0.0.1:6379` | Redis 地址 |
| `REDIS_PASSWORD` | 空 | Redis 密码 |
| `JWT_SIGNING_KEY` | 内置默认值 | 登录/鉴权签名密钥 |
| `LOGIN_BEARER_TOKEN` | 内置默认值 | `/login` 接口鉴权头 |
| `APP_ID` | 内置默认值 | SDK Token appId |
| `APP_KEY` | 内置默认值 | SDK Token appKey |
| `CLOUDFLARE_BASE_URL` | `https://demo.putplay.cc` | 外部控制接口地址 |
| `UPLOAD_BASE_DIR` | `/var/data` | 上传根目录 |
| `MAX_UPLOAD_BYTES` | `20971520` | 上传大小限制（字节） |
| `UPLOAD_ALLOWED_TYPES` | 空 | 允许上传类型，逗号分隔；为空表示不限制 |
| `WS_ALLOWED_ORIGINS` | 空 | 允许 WebSocket Origin，逗号分隔；为空表示不限制 |
| `OUTBOUND_HTTP_TIMEOUT` | `10s` | 外部 HTTP 请求超时 |
| `SHUTDOWN_TIMEOUT` | `10s` | 优雅停机超时 |

## 交付基线（本次已完成）

- 环境变量配置化，移除核心硬编码依赖。
- HTTP 服务增加超时与优雅停机。
- 修复多处 `log.Fatalf` 导致的进程退出风险。
- 修复 `clients` 并发读取风险。
- 上传接口增加安全校验与大小限制。
- 统一关键接口 JSON 响应与请求体解码逻辑。

## 目录结构

```text
.
├── api/                    # 对外接口定义（版本化）
│   └── http/v1/            # HTTP v1 请求/响应结构
├── hack/                   # 开发工具与脚本
├── internal/               # 内部实现（对外隐藏）
│   ├── cmd/                # 启动入口
│   ├── consts/             # 常量定义
│   ├── controller/         # 接口路由与接入层
│   ├── dao/                # 数据访问层
│   │   └── db/
│   ├── model/              # 公共模型定义
│   │   ├── do/
│   │   └── entity/
│   └── service/            # 业务实现
├── manifest/               # 交付清单（配置/部署/镜像/协议）
├── resource/               # 静态资源
├── go.mod
└── main.go
```

### 分层职责映射

- `api` + `controller`：对外接口定义与接入处理。
- `service`：业务逻辑实现与封装。
- `dao`：数据访问收口（Redis/DB 等）。
- `model`：公共业务模型与实体定义。

## model 使用示例（业务模型）

以版本更新链路为例：

- `api/http/v1/UpdateVersionReq`：HTTP 入参结构（接入层）。
- `internal/model/do/UpdateVersionInput`：service 入参业务模型（Input）。
- `internal/model/entity/Version`：持久化实体（Entity）。
- `internal/model/do/CheckVersionOutput`：service 出参业务模型（Output）。

调用路径：

1. `controller` 注册 `/updateVersion` 与 `service.updateVersionHandler`
2. `updateVersionHandler` 把 API 请求转换为 `do.UpdateVersionInput`
3. `service.saveVersionByModel` 把 Input 转为 `entity.Version`
4. `dao.SaveVersion` 执行 Redis 持久化
5. `signaling.updateApp` 通过 `service.checkVersionByModel` 返回 `do.CheckVersionOutput`
